
# Static Website Hosting on AWS

This is a simple personal portfolio website hosted using AWS S3, Route 53 for domain routing, and CloudFront for faster content delivery.

## Features
- Hosted static website on Amazon S3
- Custom domain configuration with Route 53
- Performance optimization using CloudFront CDN
- Secure access and versioning

## Technologies Used
- HTML, CSS
- Amazon S3, Route 53, CloudFront, IAM

## How to Deploy
1. Create an S3 bucket and enable static website hosting.
2. Upload `index.html` and `style.css` to the bucket.
3. Use Route 53 to connect a domain (optional).
4. Set up CloudFront for caching and performance.
